/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Sql;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import Sql.conexion;
import Vistas.Estudiantes;
import Vistas.cuestionario;
import java.sql.Date;
import javax.swing.JComboBox;

public class crudUsuarios {

    public static PreparedStatement sentencia_preparada;
    public static ResultSet resultado;
    public static String sql;

    public String buscarUsuario(String codigo, String clave) {
        String busquedaUsuario = null;
        Connection con = null;

        try {
            con = conexion.Conectar();
            String sentenciaBuscarUsuario = ("SELECT codigo, password FROM vistaacesso WHERE codigo = '" + codigo + "' && password = '" + clave + "'");
            sentencia_preparada = con.prepareStatement(sentenciaBuscarUsuario);
            resultado = sentencia_preparada.executeQuery();
            if (resultado.next()) {
                busquedaUsuario = "usuario encontrado";
            } else {
                busquedaUsuario = "usuario no encontrado";

            }
            con.close();
        } catch (Exception e) {
        }
        return busquedaUsuario;
    }

    public static String buscarRol(String codigo) {
        String buscarRol = null;
        Connection con;
        try {
            con = conexion.Conectar();
            String sentenciaBuscar = ("SELECT rol FROM vistaacesso WHERE codigo = '" + codigo + "'");
            sentencia_preparada = con.prepareStatement(sentenciaBuscar);
            resultado = sentencia_preparada.executeQuery();

            if (resultado.next()) {
                String nombre = resultado.getString("rol");
                buscarRol = (nombre);
            }
            con.close();
        } catch (Exception e) {

        }
        return buscarRol;
    }
public static String buscarCodigo(String codigo) {
        String buscarCode = null;
        Connection con;
        try {
            con = conexion.Conectar();
            String sentenciaBuscar = ("SELECT codigo FROM vistaacesso WHERE codigo = '" + codigo + "'");
            sentencia_preparada = con.prepareStatement(sentenciaBuscar);
            resultado = sentencia_preparada.executeQuery();

            if (resultado.next()) {
                String code = resultado.getString("codigo");
                buscarCode = (code);
            }
            con.close();
        } catch (Exception e) {

        }
        return buscarCode;
    }
public static String buscarCodigoMsn(String codigo) {
        String buscarCode = null;
        Connection con;
        try {
            con = conexion.Conectar();
            String sentenciaBuscar = ("SELECT id_alumno FROM msn WHERE id_alumno = '" + codigo + "'");
            sentencia_preparada = con.prepareStatement(sentenciaBuscar);
            resultado = sentencia_preparada.executeQuery();

            if (resultado.next()) {
                String code = resultado.getString("id_alumno");
                buscarCode = (code);
            }
            con.close();
        } catch (Exception e) {

        }
        return buscarCode;
    }
    public static String buscarNombre(String codigo) {
        String buscar = null;
        Connection con;
        try {
            con = conexion.Conectar();
            String sentenciaBuscar = ("SELECT nombre FROM vistaacesso WHERE codigo = '" + codigo + "'");
            sentencia_preparada = con.prepareStatement(sentenciaBuscar);
            resultado = sentencia_preparada.executeQuery();

            if (resultado.next()) {
                String nombre = resultado.getString("nombre");
                buscar = (nombre);
            }
            con.close();
        } catch (Exception e) {

        }
        return buscar;
    }

    public static String buscar(String codigo) {
        String buscar = null;
        Connection con;
        try {
            con = conexion.Conectar();
            String sentenciaBuscar = ("SELECT no_matricula FROM vistaalumnos WHERE no_matricula = '" + codigo + "'");
            sentencia_preparada = con.prepareStatement(sentenciaBuscar);
            resultado = sentencia_preparada.executeQuery();

            if (resultado.next()) {
                String nombre = resultado.getString("no_matricula");
                buscar = (nombre);
            }
            con.close();
        } catch (Exception e) {

        }
        return buscar;
    }

    public static String Consulta(String codigo) {
        String buscar = null;
        Connection con = null;
        String var = "ING_SIST 128CSIS-1";
        String sql = "SELECT no_matricula,nombre,grupo_clase FROM vistaalumnos WHERE no_matricula = '" + codigo + "'";
        try {
            con = conexion.Conectar();
            sentencia_preparada = con.prepareStatement(sql);
            resultado = sentencia_preparada.executeQuery();
            if (resultado.next()) {

                buscar = "bien";
            } else {
                buscar = "no";
            }
        } catch (Exception e) {
        }
        return buscar;

    }

     public static String buscarGrupo(String codigo) {
        String buscar = null;
        Connection con;
        try {
            con = conexion.Conectar();
            String sentenciaBuscar = ("SELECT grupo_clase FROM vistaalumnos where no_matricula = '" + codigo + "'");
            sentencia_preparada = con.prepareStatement(sentenciaBuscar);
            resultado = sentencia_preparada.executeQuery();

            if (resultado.next()) {
                String nombre = resultado.getString("grupo_clase");
                buscar = (nombre);
            }
            con.close();
        } catch (Exception e) {

        }
        return buscar;  
        
    }
     public int EnviarMsn(String nombre,String asunto,String envio,String respuesta,String id_alumno,String estado,String fecha,String id_profesor){
        int resultado =0;
        Connection con= null;
        String sql = ("INSERT INTO msn (nombre,Asunto,envio,respuesta,id_alumno,estado,fecha,id_profe) VALUES(?,?,?,?,?,?,?,?) ");
        
         try {
             con = conexion.Conectar();
             sentencia_preparada = con.prepareStatement(sql);
             sentencia_preparada.setString(1, nombre);
             sentencia_preparada.setString(2, asunto);
             sentencia_preparada.setString(3, envio);
             sentencia_preparada.setString(4, respuesta);
             sentencia_preparada.setString(5, id_alumno);
             sentencia_preparada.setString(6, estado);
             sentencia_preparada.setString(7, fecha);
             sentencia_preparada.setString(8, id_profesor);
             resultado = sentencia_preparada.executeUpdate();
             sentencia_preparada.close();
             con.close();
         } catch (Exception e) {
             System.out.println("ERROR:   "+e);
         }
        return resultado;
        
         
     
     }
     
     public void comboNoControlEscrito(JComboBox comboNoControlEscrito) {//Llenar un combo box de informacion de una bd
        String buscarEscuela = null;
        Connection con = null;
        try {
             con = conexion.Conectar();
            String sentenciaBuscar = ("SELECT no_control FROM controles_Escritos;");
            sentencia_preparada = con.prepareStatement(sentenciaBuscar);
            resultado = sentencia_preparada.executeQuery();
            while (resultado.next()) {//.next recorre todos los resultados guardados en la variable result
                comboNoControlEscrito.addItem(resultado.getString("no_control"));
            }
            con.close();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error " + e);
        }
    }
     
      public void comboNoControlPractico(JComboBox comboNoControlPractico) {//Llenar un combo box de informacion de una bd
        String buscarEscuela = null;
        Connection con = null;
        try {
             con = conexion.Conectar();
            String sentenciaBuscar = ("SELECT cod_practica FROM controles_Practicos");
            sentencia_preparada = con.prepareStatement(sentenciaBuscar);
            resultado = sentencia_preparada.executeQuery();
            while (resultado.next()) {//.next recorre todos los resultados guardados en la variable result
                comboNoControlPractico.addItem(resultado.getString("cod_practica"));
            }
            con.close();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error " + e);
        }
    }
     
    
}
