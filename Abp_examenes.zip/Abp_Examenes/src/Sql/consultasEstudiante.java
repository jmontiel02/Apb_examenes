/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Sql;

import static Sql.crudUsuarios.resultado;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

/**
 *
 * @author Jesus Montiel
 */
public class consultasEstudiante {
     public static PreparedStatement sentencia_preparada;
    public static ResultSet resultado;
    public static String sql;


    public String buscarCalificacionEscritos(String codigo) {
        String calificacion = null;
        Connection con= null;

        try {
            con = conexion.Conectar();
            String sentenciaBuscarCalificacion = ("SELECT calificacion FROM alumnos_controles_escritos WHERE alumnos_no_matricula = '" + codigo + "'");
            sentencia_preparada = con.prepareStatement(sentenciaBuscarCalificacion);
            resultado = sentencia_preparada.executeQuery();
            if (resultado.next()) {
                String clf = resultado.getString("calificacion");
                calificacion = (clf);
            }
            con.close();
        } catch (Exception e) {

        }
        return calificacion;
    }
     public String buscarCalificacionPracticos(String codigo) {
        String calificacion = null;
        Connection con= null;

        try {
            con = conexion.Conectar();
            String sentenciaBuscarCalificacion = ("SELECT calificacion FROM alumnos_controles_practicos WHERE alumnos_no_matricula = '" + codigo + "'");
            sentencia_preparada = con.prepareStatement(sentenciaBuscarCalificacion);
            resultado = sentencia_preparada.executeQuery();
            if (resultado.next()) {
                String clf = resultado.getString("calificacion");
                calificacion = (clf);
            }
            con.close();
        } catch (Exception e) {

        }
        return calificacion;
    }
}
