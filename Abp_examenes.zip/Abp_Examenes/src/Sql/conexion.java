/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Sql;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Jesus Montiel
 */
public class conexion {

    private static Connection con;
    private static final String driver = "com.mysql.jdbc.Driver";
    private static final String user = "JM-BP";
    private static final String pass = "123456";
    private static final String url = "jdbc:mysql://localhost:3306/examenes";

    public static Connection Conectar() {
        con = null;
        try {
            Class.forName(driver);
            con = DriverManager.getConnection(url, user, pass);
            if (con != null) {
                System.out.println("Conexion exitosa");

            }
        } catch (ClassNotFoundException | SQLException e) {
            System.out.println("Error " + e);
        }
        return con;
    }

    public Connection getConnection() {
        return con;
    }

    public static Connection desconectar() {
        con = null;
        if (con == null) {
            System.out.println("Conexion terminada");
        }
        return con;
    }

    public String registrarAlumno(int noMatricula, String nombre, String grupoClase, String fecha,float calificacionEscrito, float calificacionPractico, int noControlEscrito, int noControlPractico) {
        String resultado;
        Connection miConexion = null;
        String insertarAlumnos = ("INSERT INTO alumnos(no_matricula, nombre, grupo_clase) VALUES ('" + noMatricula + "','" + nombre + "', '" + grupoClase + "')");
        String insertarAcceso = ("INSERT INTO acceso(codigo, nombre, password, rol) "
                + "VALUES ('" + noMatricula + "', '" + nombre + "', '" + noMatricula + "', 'alumno')");
        String insertarCalificacionControlEscrito = ("INSERT INTO alumnos_controles_escritos(fecha, calificacion, alumnos_no_matricula, controles_escritos_no_control)"
                + " VALUES ('" + fecha + "','" + calificacionEscrito + "', '" + noMatricula + "', '" + noControlEscrito + "')");
        String insertarCalificacionControlPractico = ("INSERT INTO alumnos_controles_practicos(fecha, calificacion, alumnos_no_matricula, controles_practicos_cod_practica)"
                + " VALUES ('" + fecha + "','" + calificacionPractico + "', '" + noMatricula + "', '" + noControlPractico + "')");

        try {
            miConexion = DriverManager.getConnection(url, user, pass);

            miConexion.setAutoCommit(false);
            Statement miStatement = miConexion.createStatement();

            miStatement.executeUpdate(insertarAlumnos);
            miStatement.executeUpdate(insertarAcceso);
            miStatement.executeUpdate(insertarCalificacionControlEscrito);
            miStatement.executeUpdate(insertarCalificacionControlPractico);
            miConexion.commit();
            resultado = "Todo Ok";
        } catch (SQLException e) {
            resultado = "Ocurrió un error, no se hizo";
            System.out.println("ERROR:   " + e);

            if (miConexion != null) {
                try {
                    miConexion.rollback();
                } catch (SQLException ex) {
                    Logger.getLogger(conexion.class.getName()).log(Level.SEVERE, null, ex);
                }
            }

        }

        return resultado;
    }
}
