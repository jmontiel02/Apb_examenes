/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Principal;

import Sql.conexion;
import java.awt.Color;
import java.awt.Component;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.swing.JTable;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author Jesus Montiel
 */
public class Cambiar extends DefaultTableCellRenderer {

    float prom = 0;

    public void BuscarxNombre(JTable tabla) {
        DefaultTableModel data = new DefaultTableModel();

        data.addColumn("N° Matricula");
        data.addColumn("Nombre");
        data.addColumn("Promedio");
        data.addColumn("Grupo clase");

//data.addColumn("Control Escrito");
        tabla.setModel(data);
        String sql;
        sql = "select alumnos_no_matricula,nombre, round(avg(calificacion),2), grupo_clase AS prom from vistaalumnos inner join vistaalmunoscontrolesescritos\n"
                + "on vistaalumnos.no_matricula = vistaalmunoscontrolesescritos.alumnos_no_matricula\n"
                + " group by alumnos_no_matricula";
//    if (nombre.equals("")) {
//        sql= "";
//    } else {
//        sql =" select no_matricula,nombre,grupo_clase,fecha,calificacion from vistaalumnos INNER JOIN vistaalmunoscontrolesescritos ON vistaalumnos.no_matricula = vistaalmunoscontrolesescritos.alumnos_no_matricula where nombre like '"+nombre+"%' AND grupo_clase ='"+var+"'";
//        
//        
//    }
        String acc[] = new String[4];
        Statement st;
        int i = 0;
        try {
            st = conexion.Conectar().createStatement();
            ResultSet res = st.executeQuery(sql);

            while (res.next()) {
                i++;
                acc[0] = res.getString(1);
                acc[1] = res.getString(2);
                acc[2] = res.getString(3);
                acc[3] = res.getString(4);

                // acc[5] = res.getString(6)
                data.addRow(acc);

            }
            tabla.setModel(data);
            //LblPromIngSistema.setText(PromIngSistema(var));
        } catch (Exception e) {
        }
    }

    public void BuscarxNombrePractico(JTable tabla) {
        DefaultTableModel data = new DefaultTableModel();

        data.addColumn("N° Matricula");
        data.addColumn("Nombre");
        data.addColumn("Promedio");
        data.addColumn("Grupo clase");

//data.addColumn("Control Escrito");
        tabla.setModel(data);
        String sql;
        sql = "select alumnos_no_matricula,nombre, round(avg(calificacion),2), grupo_clase AS prom from vistaalumnos inner join vistaalumnoscontrolespracticos\n"
                + "on vistaalumnos.no_matricula = vistaalumnoscontrolespracticos.alumnos_no_matricula\n"
                + " group by alumnos_no_matricula";
//    if (nombre.equals("")) {
//        sql= "";
//    } else {
//        sql =" select no_matricula,nombre,grupo_clase,fecha,calificacion from vistaalumnos INNER JOIN vistaalmunoscontrolesescritos ON vistaalumnos.no_matricula = vistaalmunoscontrolesescritos.alumnos_no_matricula where nombre like '"+nombre+"%' AND grupo_clase ='"+var+"'";
//        
//        
//    }
        String acc[] = new String[4];
        Statement st;
        int i = 0;
        try {
            st = conexion.Conectar().createStatement();
            ResultSet res = st.executeQuery(sql);

            while (res.next()) {
                i++;
                acc[0] = res.getString(1);
                acc[1] = res.getString(2);
                acc[2] = res.getString(3);
                acc[3] = res.getString(4);

                // acc[5] = res.getString(6)
                data.addRow(acc);

            }
            tabla.setModel(data);
            //LblPromIngSistema.setText(PromIngSistema(var));
        } catch (Exception e) {
        }
    }

    public void buscarxCarrera(JTable tabla, String carrera) {
        DefaultTableModel data = new DefaultTableModel();

        data.addColumn("N° Matricula");
        data.addColumn("Nombre");
        data.addColumn("Promedio");
        data.addColumn("Grupo clase");

//data.addColumn("Control Escrito");
        tabla.setModel(data);
        String sql;
        sql = "select alumnos_no_matricula,nombre, round(avg(calificacion),2),grupo_clase AS prom from vistaalumnos inner join vistaalmunoscontrolesescritos\n"
                + "on vistaalumnos.no_matricula = vistaalmunoscontrolesescritos.alumnos_no_matricula\n"
                + " group by alumnos_no_matricula having grupo_clase = '" + carrera + "'";
//    if (nombre.equals("")) {
//        sql= "";
//    } else {
//        sql =" select no_matricula,nombre,grupo_clase,fecha,calificacion from vistaalumnos INNER JOIN vistaalmunoscontrolesescritos ON vistaalumnos.no_matricula = vistaalmunoscontrolesescritos.alumnos_no_matricula where nombre like '"+nombre+"%' AND grupo_clase ='"+var+"'";
//        
//        
//    }
        String acc[] = new String[4];
        Statement st;
        int i = 0;
        try {
            st = conexion.Conectar().createStatement();
            ResultSet res = st.executeQuery(sql);

            while (res.next()) {
                i++;
                acc[0] = res.getString(1);
                acc[1] = res.getString(2);
                acc[2] = res.getString(3);
                acc[3] = res.getString(4);

                // acc[5] = res.getString(6)
                data.addRow(acc);

            }
            tabla.setModel(data);
            //LblPromIngSistema.setText(PromIngSistema(var));
        } catch (Exception e) {
        }
    }

    @Override
    public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {
        float valor = 0;

        valor = Float.parseFloat(table.getValueAt(row, 2).toString());
        if (valor < 3) {
            setBackground(Color.red);
            setForeground(Color.BLACK);
        } else if(valor >3 && valor <= 3.5){
            setBackground(Color.yellow);
            setForeground(Color.BLACK);
        }else{
          setBackground(Color.GREEN);
            setForeground(Color.BLACK);
        }
        return super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column); //To change body of generated methods, choose Tools | Templates.
    }

    public void buscarxCarreraPractico(JTable tabla, String carrera) {
        DefaultTableModel data = new DefaultTableModel();

        data.addColumn("N° Matricula");
        data.addColumn("Nombre");
        data.addColumn("Promedio");
        data.addColumn("Grupo clase");

//data.addColumn("Control Escrito");
        tabla.setModel(data);
        String sql;
        sql = "select alumnos_no_matricula,nombre, round(avg(calificacion),2),grupo_clase AS prom from vistaalumnos inner join vistaalumnoscontrolespracticos\n"
                + "on vistaalumnos.no_matricula = vistaalumnoscontrolespracticos.alumnos_no_matricula\n"
                + " group by alumnos_no_matricula having grupo_clase = '" + carrera + "'";
//    if (nombre.equals("")) {
//        sql= "";
//    } else {
//        sql =" select no_matricula,nombre,grupo_clase,fecha,calificacion from vistaalumnos INNER JOIN vistaalmunoscontrolesescritos ON vistaalumnos.no_matricula = vistaalmunoscontrolesescritos.alumnos_no_matricula where nombre like '"+nombre+"%' AND grupo_clase ='"+var+"'";
//        
//        
//    }
        String acc[] = new String[4];
        Statement st;
        int i = 0;
        try {
            st = conexion.Conectar().createStatement();
            ResultSet res = st.executeQuery(sql);

            while (res.next()) {
                i++;
                acc[0] = res.getString(1);
                acc[1] = res.getString(2);
                acc[2] = res.getString(3);
                acc[3] = res.getString(4);

                // acc[5] = res.getString(6)
                data.addRow(acc);

            }
            tabla.setModel(data);
            //LblPromIngSistema.setText(PromIngSistema(var));
        } catch (Exception e) {
        }
    }

}
